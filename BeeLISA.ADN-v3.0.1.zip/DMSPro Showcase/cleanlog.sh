#!/bin/sh

if [ -z "$1" ];then
echo "command invalid, missing 1st param"
exit 1
fi
if [ -z "$2" ];then
echo "command invalid, missing 2nd param"
exit 1
fi

file_name=$1
max_size=$2

size=$(wc -c "$file_name" | tail -1 | awk '{print $1}')
echo "size is $size bytes, max_size is "$max_size""

if [ $size -lt $max_size ]; 
then
  echo "file is small, no need to clean now"
else
  echo "file is big, cleaning file now"
  echo "" > $file_name
fi
